import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Product = {
  id: number
  name: string
  description: string | null
  price: number
  stock: number
  image_url: string | null
  category_id: number | null
  is_active: boolean
  created_at: string
}

export type OrderItem = {
  id: number
  order_id: number
  product_id: number
  quantity: number
  unit_price: number
  product?: Product
}

export type CustomerDetails = {
  name: string
  address: string
  phone: string
}

export type Order = {
  id: number
  created_at: string
  customer_email: string
  total_amount: number
  status: 'pending' | 'paid' | 'shipped' | 'delivered' | 'cancelled'
  customer_details: CustomerDetails
  order_items?: OrderItem[]
}

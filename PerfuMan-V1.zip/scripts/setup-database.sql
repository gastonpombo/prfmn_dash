-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  stock INTEGER NOT NULL DEFAULT 0,
  image_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Create policy to allow authenticated users to read products
CREATE POLICY "Allow authenticated users to read products"
  ON products
  FOR SELECT
  TO authenticated
  USING (true);

-- Create policy to allow authenticated users to insert products
CREATE POLICY "Allow authenticated users to insert products"
  ON products
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create policy to allow authenticated users to update products
CREATE POLICY "Allow authenticated users to update products"
  ON products
  FOR UPDATE
  TO authenticated
  USING (true);

-- Create policy to allow authenticated users to delete products
CREATE POLICY "Allow authenticated users to delete products"
  ON products
  FOR DELETE
  TO authenticated
  USING (true);

-- Insert sample products
INSERT INTO products (name, price, stock, image_url) VALUES
  ('Chanel No. 5', 135.00, 25, 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=400'),
  ('Dior Sauvage', 98.00, 40, 'https://images.unsplash.com/photo-1588405748880-12d1d2a59c75?w=400'),
  ('Tom Ford Black Orchid', 165.00, 15, 'https://images.unsplash.com/photo-1547887537-6158d64c35b3?w=400')
ON CONFLICT DO NOTHING;

-- Create storage bucket for product images (this needs to be done via Supabase Dashboard or API)
-- The bucket 'products' should be created with public access for reading

-- Create categories table
CREATE TABLE IF NOT EXISTS public.categories (
  id bigint generated always as identity primary key,
  name text not null,
  image_url text null,
  created_at timestamp with time zone default timezone('utc'::text, now()),
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

-- Enable RLS
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow authenticated users to read categories"
  ON public.categories
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to insert categories"
  ON public.categories
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update categories"
  ON public.categories
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to delete categories"
  ON public.categories
  FOR DELETE
  TO authenticated
  USING (true);

-- Insert sample data
INSERT INTO public.categories (name) VALUES
  ('Perfumes'),
  ('Colonias'),
  ('Eau de Toilette')
ON CONFLICT DO NOTHING;
